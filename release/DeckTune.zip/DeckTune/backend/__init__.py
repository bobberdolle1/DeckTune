"""DeckTune Backend - Automated undervolting and tuning for Steam Deck."""

__version__ = "1.0.0"
